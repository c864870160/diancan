/**
 * banner数据
 */ 
function getBannerData(){
    var arr = ['../../images/banner_01.png', '../../images/banner_02.png', '../../images/banner_03.png', '../../images/banner_04.png']
    return arr
}
/*
 * 首页 navnav 数据
 */ 
function getIndexNavData(){
    var arr = [
            {
                id:1,
                icon:"../../images/nav_icon_01.png",
                title:"推荐"
            },
            {
                id:2,
                icon:"../../images/nav_icon_02.png",
                title:"火锅"
            },
            {
                id:3,
                icon:"../../images/nav_icon_03.png",
                title:"日料"
            },
            {
                id:4,
                icon:"../../images/nav_icon_04.png",
                title:"快餐"
            },
            {
                id:5,
                icon:"../../images/nav_icon_05.png",
                title:"西餐"
            }
        ]
    return arr
}
/*
 * 首页 对应 标签 数据项
 */ 
function getIndexNavSectionData(){
    var arr = [
                [
                    {
                        
                        subject:"重庆老火锅",
                        coverpath:"../../images/recommend_img_01.png",
                        price:'¥60/人',
                        message:'富含重庆特色的本地老火锅！'
                    },
                    {
                        
                        subject:"若伊餐厅",
                        coverpath:"../../images/recommend_img_02.png",
                        price:'¥100/人',
                        message:'吃是一种享受！'
                    },
                    {
                        
                        subject:"桃太郎日本料理",
                        coverpath:"../../images/recommend_img_03.png",
                        price:'¥250',
                        message:'吃尽他国味蕾！'
                    },
                    {
                        
                        subject:"小李子快餐店",
                        coverpath:"../../images/recommend_img_05.png",
                        price:'¥15',
                        message:'打工人的最佳选择。'
                    },
                    {
                        
                        subject:"三次郎日料",
                        coverpath:"../../images/recommend_img_06.png",
                        price:'¥150',
                        message:'味觉的享受。'
                    }
                ],
                [
                    {
                        artype:'nails',
                        subject:"重庆老火锅",
                        coverpath:"../../images/recommend_img_01.png",
                        price:'¥60/人',
                        message:'富含重庆特色的本地老火锅！'
                    }
                ],
                [
                    {
                        artype:'beauty',
                        subject:"桃太郎日本料理",
                        coverpath:"../../images/recommend_img_03.png",
                        price:'¥250',
                        message:'吃尽他国味蕾！'
                    },
                    {
                        artype:'beauty',
                        subject:"三次郎日料",
                        coverpath:"../../images/recommend_img_06.png",
                        price:'¥150',
                        message:'味觉的享受。'
                    }
                ],
                [
                    
                    {
                        artype:'hair',
                        subject:"小李子快餐店",
                        coverpath:"../../images/recommend_img_05.png",
                        price:'¥15',
                        message:'打工人的最佳选择。'
                    }
                ],
                [
                    {
                        artype:'eyelash',
                        subject:"若伊餐厅",
                        coverpath:"../../images/recommend_img_02.png",
                        price:'¥200/人',
                        message:'吃是一种享受！'
                    }
                ] 
            ]
    return arr
}
/**
 * 点餐 数据
 * */ 
function getSkilledData(){
    var arr = [
                {
                        company:"风味快餐",
                        avatar:"../../images/skilledt_img_01.png",
                        nickname:'张师傅',
                        price:'¥20',
                        message:'打工人的选择。',
                        distance:'100m'
                    },
                    {
                        company:"小江湖",
                        avatar:"../../images/skilledt_img_02.png",
                        nickname:'陈师傅',
                        price:'¥100',
                        message:'从事美食行业10余年，有丰富经验',
                        distance:'200m'
                    },
                    {
                        company:"巴适火锅",
                        avatar:"../../images/skilledt_img_03.png",
                        nickname:'王师傅',
                        price:'¥600',
                        message:'从事美食行业20余年，有丰富经验',
                        distance:'300m'
                    },
                    {
                        company:"日式料理",
                        avatar:"../../images/skilledt_img_04.png",
                        nickname:'三次郎',
                        price:'¥100',
                        message:'从事美食行业15余年，有丰富经验',
                        distance:'400m'
                    }
            ]
    return arr
}

/**
 * 选择器 数据
 */ 
function getPickerData(){
    var arr =[
        {
            name:'张三',
            phone:'13812314563',
            province:'北京',
            city:'北京',
            addr:'朝阳区望京悠乐汇A座8011'
        },
        {
            name:'李四',
            phone:'13812314563',
            province:'北京市',
            city:'北京市',
            addr:'朝阳区望京悠乐汇A座4020'
        }
    ]
    return  arr
}
/**
 * 查询 地址
 * */ 
var user_data = userData()
function searchAddrFromAddrs(addrid){
    var result
    for(let i=0;i<user_data.addrs.length;i++){
        var addr = user_data.addrs[i]
        console.log(addr)
        if(addr.addrid == addrid){
            result = addr
        }
    }
    return result || {}
}
/**
 * 用户数据
 * */ 
function userData(){
    var arr = {
                uid:'1',
                nickname:'吃货',
                name:'张三',
                phone:'15888887998',
                avatar:'../../images/avatar.png',
                addrs:[
                   {
                        addrid:'1',
                        name:'张三',
                        phone:'15888887998',
                        province:'重庆',
                        city:'直辖市',
                        addr:'南岸区南山街道崇教路1号'
                    },
                    {
                        addrid:'2',
                        name:'李四',
                        phone:'135135465843',
                        province:'重庆',
                        city:'直辖市',
                        addr:'南岸区四公里地铁交汇处'
                    } 
                ]
            }
    return arr
}
/**
 * 省
 * */ 
function provinceData(){
    var arr = [
        // {pid:1,pzip:'110000',pname:'北京市'},
        // {pid:2,pzip:'120000',pname:'天津市'}
        '请选择省份','福建省'
    ]
    return arr
}
/**
 * 市
 * */ 
function cityData(){
    var arr = [
        // {cid:1,czip:'110100',cname:'市辖区',pzip:'110000'},
        // {cid:2,czip:'120100',cname:'市辖区',pzip:'120000'}
        '请选择城市','福州市','厦门市','宁德市'
    ]
    return arr
}
/*
 * 对外暴露接口
 */ 
module.exports = {
  getBannerData : getBannerData,
  getIndexNavData : getIndexNavData,
  getIndexNavSectionData : getIndexNavSectionData,
  getPickerData : getPickerData,
  getSkilledData :getSkilledData,
  userData : userData,
  provinceData : provinceData,
  cityData : cityData,
  searchAddrFromAddrs : searchAddrFromAddrs

}